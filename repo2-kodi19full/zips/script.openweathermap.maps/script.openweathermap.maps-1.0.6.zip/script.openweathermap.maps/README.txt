INFO FOR SKINNERS

Window properties provided by this addon:

MAP [1-5]
---------
Map.IsFetched
Map.%i.Area
Map.%i.Layer
Map.%i.Heading
Map.%i.Legend

