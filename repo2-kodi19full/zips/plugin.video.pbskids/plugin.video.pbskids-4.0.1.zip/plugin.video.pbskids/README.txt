plugin.video.pbskids
================

Kodi Addon for Think TV PBS Kids Video website

Version 4.0.0 Initial release for Matrix