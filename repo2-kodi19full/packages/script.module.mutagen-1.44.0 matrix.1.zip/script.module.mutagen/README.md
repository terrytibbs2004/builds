![Mutagen](icon.png)

Kodi module containing [Mutagen](https://mutagen.readthedocs.io).
