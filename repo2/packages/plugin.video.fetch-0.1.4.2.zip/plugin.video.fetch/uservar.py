# Python code obfuscated by www.development-tools.net 
 

import base64, codecs
magic = 'JycnCi0tLS0tLS0tLS1FZGl0IHJlcXVpcmVkLS0tLS0tLS0tClNldCBwbHVnaW5pZCB0byBzYW1lIG5hbWUgYXMgYWRkb24gaWQgaW4gYWRkb24ueG1sCicnJwpwbHVnaW5pZCA9ICdwbHVnaW4udmlkZW8uZmV0Y2gnCgoKJycnIAotLS0tL'
love = 'F0gYF0gEJEcqPOlMKS1nKWyMP0gYF0gYF0gYDcTo3Vto25fnJ5yVUugoPOzo3Vtp291pzAypljtMJEcqPO0nTHtnT9mqPO0olO0nTHtqKWfVT9zVUEbMFOznJkyVTuip3D9W2u0qUN6Yl9mo21yqTucozphL29gY3AiqKWwMKZhrT1fWjcTo3'
god = 'IgbG9jYWwgeG1sIGZpbGUsIGVkaXQgdGhlIGhvc3QgdG8gbG9jYWwgaG9zdD0nbG9jYWwnIGFuZCBjYWxsIHRoZSBmaWxlICdzb3VyY2VzLnhtbCcgYW5kIHBsYWNlIGluIHRoZSBmb2xkZXIKcGxlYXNlIHNlZSBzYW1wbGUueG1sIGZvciB'
destiny = 'fLKyiqKDXo24toTyhMFOmo3IlL2HtL2ShVTWyVTIcqTuypvObqUEjplOipvObqUEjPvpaWjbXnT9mqQ0anUE0pUZ6Yl9anKEfLJVhL29gY2yznKEmoz90rJ91paAxo250qKAynKDinJ5cqTMyqTAbY3Wuql9gLJyhY3AiqKWwMKZhrT1fWj=='
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))