Repository and Addon Update Script 0.0.1

Relase date: April 2021

Actions:

	Display Notification

	Refresh Local Addons

	Refresh Repos

	Return to Home Screen